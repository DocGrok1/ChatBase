export default function StatusCards() {
  const cards = [
    {
      title: 'Conversation lane',
      text: 'Public conversational surface with staged LLM routing and thread persistence.'
    },
    {
      title: 'Reasoning lane',
      text: 'Adjudication layer kept open for Jupiter-style governance and future capital routing.'
    },
    {
      title: 'Memory lane',
      text: 'Supabase-backed session, message, upload, and connector continuity.'
    }
  ];

  return (
    <div className="grid-3">
      {cards.map(card => (
        <div className="card" key={card.title}>
          <div className="label">Lane</div>
          <h3>{card.title}</h3>
          <p className="muted">{card.text}</p>
        </div>
      ))}
    </div>
  );
}
