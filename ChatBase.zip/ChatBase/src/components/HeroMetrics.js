export default function HeroMetrics() {
  const metrics = [
    { label: 'Active agents', value: '160' },
    { label: 'LLM lanes', value: '3' },
    { label: 'Open platforms', value: '3' },
    { label: 'Runtime state', value: 'LIVE' }
  ];

  return (
    <div className="grid-2">
      {metrics.map((metric) => (
        <div className="metric" key={metric.label}>
          <div className="metric-label">{metric.label}</div>
          <div className="metric-value">{metric.value}</div>
        </div>
      ))}
    </div>
  );
}
