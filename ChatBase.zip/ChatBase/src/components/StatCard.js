import { theme } from './theme';

export default function StatCard({ label, value, subvalue }) {
  return (
    <div style={styles.card}>
      <div style={styles.label}>{label}</div>
      <div style={styles.value}>{value}</div>
      {subvalue ? <div style={styles.sub}>{subvalue}</div> : null}
    </div>
  );
}

const styles = {
  card: {
    background: theme.panel,
    border: `1px solid ${theme.border}`,
    borderRadius: '16px',
    padding: '18px',
    boxShadow: theme.glow
  },
  label: {
    color: theme.neon,
    fontSize: '12px',
    textTransform: 'uppercase',
    letterSpacing: '1.2px',
    marginBottom: '10px',
    fontWeight: 700
  },
  value: { fontSize: '28px', fontWeight: 800, color: theme.text },
  sub: { marginTop: '8px', color: theme.muted, fontSize: '14px' }
};
