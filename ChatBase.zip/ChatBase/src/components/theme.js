export const theme = {
  neon: '#62ff9b',
  bg: '#07110c',
  panel: '#0c1811',
  panel2: '#102117',
  border: '#1d7f47',
  text: '#e8fff1',
  muted: '#a7d9b9',
  glow: '0 0 24px rgba(98,255,155,0.14)'
};
