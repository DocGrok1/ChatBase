import { theme } from './theme';

export default function AgentNodes({ agents }) {
  return (
    <div style={styles.wrap}>
      {agents.map((agent) => (
        <div key={agent.id} style={styles.card}>
          <div style={styles.top}>
            <div>
              <div style={styles.name}>{agent.name}</div>
              <div style={styles.role}>{agent.role}</div>
            </div>
            <span style={{ ...styles.pill, ...pill(agent.status) }}>{agent.status}</span>
          </div>
          <div style={styles.task}>Task: {agent.currentTask || 'Waiting'}</div>
          <div style={styles.meta}>Platform: {agent.platform || 'General'} · Lane: {agent.lane}</div>
        </div>
      ))}
    </div>
  );
}

function pill(status) {
  const map = {
    IDLE: { color: '#d7ffe6', background: '#102117' },
    QUEUED: { color: '#041008', background: '#b0ffcb' },
    RUNNING: { color: '#041008', background: '#62ff9b' },
    DONE: { color: '#041008', background: '#8dffc4' },
    FAILED: { color: '#fff1f1', background: '#5a1a1a' }
  };
  return map[status] || map.IDLE;
}

const styles = {
  wrap: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
    gap: '14px'
  },
  card: {
    background: theme.panel,
    border: `1px solid ${theme.border}`,
    borderRadius: '16px',
    padding: '14px',
    boxShadow: theme.glow
  },
  top: {
    display: 'flex',
    justifyContent: 'space-between',
    gap: '10px',
    marginBottom: '10px'
  },
  name: { color: theme.neon, fontWeight: 700, fontSize: '18px' },
  role: { color: theme.muted, fontSize: '13px', marginTop: '4px' },
  pill: {
    borderRadius: '999px',
    padding: '6px 10px',
    fontSize: '11px',
    fontWeight: 700,
    alignSelf: 'flex-start'
  },
  task: { color: theme.text, fontSize: '14px', marginBottom: '8px' },
  meta: { color: theme.muted, fontSize: '12px', lineHeight: 1.5 }
};
