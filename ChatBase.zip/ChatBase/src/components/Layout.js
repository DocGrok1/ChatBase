import Link from 'next/link';
import { useRouter } from 'next/router';
import { useState } from 'react';
import { NAV_ITEMS } from '../lib/nav';

export default function Layout({ children }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);

  return (
    <div className="layout">
      <div className="shell">
        <div className="topbar">
          <div className="brand-wrap">
            <div className="brand-mark">CF</div>
            <div>
              <div className="brand-kicker">Public Interface Platform</div>
              <div className="brand-title">ChatFace</div>
            </div>
          </div>
          <button className="hamburger" onClick={() => setOpen(v => !v)} aria-label="Toggle navigation">
            <span />
          </button>
        </div>
        {open && (
          <div className="drawer">
            <div className="drawer-grid">
              {NAV_ITEMS.map(item => (
                <Link key={item.href} href={item.href} className={`drawer-link ${router.pathname === item.href ? 'active' : ''}`}>
                  <strong>{item.label}</strong>
                  <small>{item.blurb}</small>
                </Link>
              ))}
            </div>
          </div>
        )}
        {children}
      </div>
    </div>
  );
}
