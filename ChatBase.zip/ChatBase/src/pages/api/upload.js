export default async function handler(req, res) {
  return res.status(200).json({
    ok: true,
    note: 'Upload route scaffold is standing. Replace with multipart handling plus Supabase storage or local processing.'
  });
}
