export default async function handler(req, res) {
  return res.status(200).json({
    ok: true,
    note: 'Whisper route scaffold is standing. Connect microphone or audio uploads to your chosen transcription backend.'
  });
}
