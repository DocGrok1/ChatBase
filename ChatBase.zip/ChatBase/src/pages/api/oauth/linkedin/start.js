export default function handler(req, res) {
  return res.status(200).json({
    ok: true,
    platform: 'linkedin',
    message: 'Configure provider credentials and callback URLs, then replace this scaffold with the real OAuth redirect flow.'
  });
}
