export default function handler(req, res) {
  return res.status(200).json({
    ok: true,
    platform: 'facebook',
    message: 'OAuth callback placeholder reached. Persist provider tokens to Supabase before enabling production actions.'
  });
}
