export default function handler(req, res) {
  return res.status(200).json({
    ok: true,
    connections: [
      { platform: 'linkedin', status: 'not_connected' },
      { platform: 'x', status: 'not_connected' },
      { platform: 'facebook', status: 'not_connected' }
    ]
  });
}
