import Layout from '../components/Layout';

const platforms = [
  { name: 'LinkedIn', status: 'Ready to connect', scope: 'profile, organization, posts' },
  { name: 'X', status: 'Ready to connect', scope: 'timeline, tweets, replies' },
  { name: 'Facebook', status: 'Ready to connect', scope: 'pages, posts, messages' }
];

export default function ConnectionsPage() {
  return (
    <Layout>
      <section className="section">
        <div className="section-header">
          <div>
            <div className="label">Platform connectors</div>
            <h1 className="page-title">Connections</h1>
          </div>
          <div className="badge">OAuth scaffolds included</div>
        </div>
        <div className="grid-3">
          {platforms.map(platform => (
            <div className="card" key={platform.name}>
              <div className="label">Platform</div>
              <h3>{platform.name}</h3>
              <p className="muted">{platform.scope}</p>
              <div className="button-row">
                <a className="btn" href={`/api/oauth/${platform.name.toLowerCase()}/start`}>Connect {platform.name}</a>
                <span className="badge">{platform.status}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="section grid-2">
        <div className="card">
          <div className="label">Normalized content path</div>
          <p className="muted">Import -> normalize -> store -> draft -> review -> publish. All three platforms map into one internal content shape so agents can route work cleanly.</p>
        </div>
        <div className="card">
          <div className="label">Production note</div>
          <p className="muted">Complete provider app setup, callback URLs, and token scopes before using any connector publicly. This scaffold intentionally ships with safe placeholders.</p>
        </div>
      </section>
    </Layout>
  );
}
