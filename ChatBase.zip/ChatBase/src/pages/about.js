import Layout from '../components/Layout';

export default function AboutPage() {
  return (
    <Layout>
      <section className="section">
        <div className="section-header">
          <div>
            <div className="label">About</div>
            <h1 className="page-title">Embodied public interface</h1>
          </div>
        </div>
        <div className="grid-2">
          <div className="card">
            <p className="lead">
              ChatFace is designed as a public-facing flagship surface with dark luminous presence, bright green neon lettering, expandable multi-agent depth, and platform-scale persistence.
            </p>
          </div>
          <div className="card">
            <p className="muted">
              Structurally, it stays open enough to inherit Jupiter-style runtime depth later without forcing a redesign when capital, governance, or other higher-order engines are added back into view.
            </p>
          </div>
        </div>
      </section>
    </Layout>
  );
}
