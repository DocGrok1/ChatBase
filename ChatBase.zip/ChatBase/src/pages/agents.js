import Layout from '../components/Layout';

const agentGroups = [
  ['Ingress', '22', 'Intake, connectors, stream normalization, upload recognition.'],
  ['Conversation', '38', 'Public-facing dialogue, session handling, response shaping, prompt hygiene.'],
  ['Reasoning', '34', 'Adjudication, governance, structured synthesis, escalation routing.'],
  ['Memory', '28', 'Persistent context, retrieval, indexing, continuity, summarization.'],
  ['Publishing', '18', 'Drafting, adaptation, scheduling, social publishing workflows.'],
  ['Analytics', '20', 'Signal tracking, engagement review, reflection, platform health.']
];

export default function AgentsPage() {
  return (
    <Layout>
      <section className="section">
        <div className="section-header">
          <div>
            <div className="label">Agent hierarchy</div>
            <h1 className="page-title">160 active agent slots</h1>
          </div>
          <div className="badge">3 LLM lanes standing first</div>
        </div>
        <div className="grid-3">
          {agentGroups.map(([name, count, description]) => (
            <div className="card" key={name}>
              <div className="label">{name}</div>
              <div className="metric-value">{count}</div>
              <p className="muted">{description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="section grid-3">
        <div className="card">
          <div className="label">Lane 1</div>
          <h3>Conversation model</h3>
          <p className="muted">Handles public interaction, intent detection, platform prompts, and front-line responses.</p>
        </div>
        <div className="card">
          <div className="label">Lane 2</div>
          <h3>Reasoning model</h3>
          <p className="muted">Handles deeper synthesis, routing, structured resolution, and future Jupiter-capable expansion.</p>
        </div>
        <div className="card">
          <div className="label">Lane 3</div>
          <h3>Memory model</h3>
          <p className="muted">Handles retrieval, indexing, continuity, archival recognition, and thread summary generation.</p>
        </div>
      </section>
    </Layout>
  );
}
