import Link from 'next/link';
import Layout from '../components/Layout';
import HeroMetrics from '../components/HeroMetrics';
import StatusCards from '../components/StatusCards';

export default function Home() {
  return (
    <Layout>
      <section className="hero">
        <div className="hero-grid">
          <div>
            <div className="kicker">Open Jupiter-Class Public Surface</div>
            <h1>ChatFace</h1>
            <p className="lead">
              Public interface for governed multi-agent intelligence with bright neon presence, dark command-surface UI,
              three staged LLM lanes, and platform connectors for LinkedIn, X, and Facebook.
            </p>
            <div className="button-row">
              <Link href="/interface" className="btn">Open Interface</Link>
              <Link href="/connections" className="btn secondary">Connect Platforms</Link>
            </div>
            <div className="footer-note">
              Built to stand publicly first, while preserving Jupiter-grade ingress lines and future capital expansion hooks.
            </div>
          </div>
          <div className="panel">
            <div className="label">Launch posture</div>
            <h3>Bad to the bone public landing surface</h3>
            <p className="muted">
              Five-page navigation. Supabase persistence. Connector-ready platform core. Multi-agent expansion by staged activation.
            </p>
            <div className="button-row">
              <span className="badge">Neon mode engaged</span>
              <span className="badge">Dark surface live</span>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="section-header">
          <div>
            <div className="label">Standing platform metrics</div>
            <h2 className="page-title">Public shell with internal depth</h2>
          </div>
        </div>
        <HeroMetrics />
      </section>

      <section className="section">
        <div className="section-header">
          <div>
            <div className="label">Core operating lanes</div>
            <h2 className="page-title">Three LLM lanes first</h2>
          </div>
        </div>
        <StatusCards />
      </section>

      <section className="section grid-2">
        <div className="card">
          <div className="label">Five pages</div>
          <h3>Home, Interface, Agents, Systems, Connections</h3>
          <p className="muted">
            Hamburger navigation is included across all pages so the platform can stay lightweight publicly while holding deeper system surfaces underneath.
          </p>
        </div>
        <div className="card">
          <div className="label">Platform readiness</div>
          <h3>OAuth scaffolds included</h3>
          <p className="muted">
            Connector start and callback routes are scaffolded for LinkedIn, X, and Facebook. Add your credentials in env and finalize scopes before production use.
          </p>
        </div>
      </section>
    </Layout>
  );
}
