import Layout from '../components/Layout';

const systems = [
  { name: 'Supabase', state: 'READY', note: 'Database, auth, storage, and row-level persistence scaffolds included.' },
  { name: 'OAuth connectors', state: 'SCAFFOLDED', note: 'LinkedIn, X, and Facebook start/callback routes included as platform stubs.' },
  { name: 'API routes', state: 'LIVE', note: 'Chat, connections, and connector mock responses included for standing shell operation.' },
  { name: 'Jupiter ingress', state: 'OPEN', note: 'Capital-facing expansion hooks intentionally left available at the architectural layer.' }
];

export default function SystemsPage() {
  return (
    <Layout>
      <section className="section">
        <div className="section-header">
          <div>
            <div className="label">Runtime and persistence</div>
            <h1 className="page-title">Systems</h1>
          </div>
          <div className="badge">Dark neon platform core</div>
        </div>
        <div className="grid-2">
          {systems.map(system => (
            <div className="card" key={system.name}>
              <div className="label">{system.name}</div>
              <div className="metric-value" style={{ fontSize: 28 }}>{system.state}</div>
              <p className="muted">{system.note}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="card">
          <div className="label">Database tables</div>
          <table className="table">
            <thead>
              <tr><th>Table</th><th>Purpose</th></tr>
            </thead>
            <tbody>
              <tr><td>chatface_sessions</td><td>Conversation continuity and thread ownership.</td></tr>
              <tr><td>chatface_messages</td><td>User/system messages with lane attribution.</td></tr>
              <tr><td>chatface_agents</td><td>Agent registry, role, readiness, and hierarchy metadata.</td></tr>
              <tr><td>chatface_models</td><td>LLM lane registry and activation status.</td></tr>
              <tr><td>platform_connections</td><td>LinkedIn, X, Facebook account connection records.</td></tr>
              <tr><td>platform_posts</td><td>Normalized imported and drafted content objects.</td></tr>
            </tbody>
          </table>
        </div>
      </section>
    </Layout>
  );
}
