import { useMemo, useState } from 'react';
import Layout from '../components/Layout';
import AgentNodes from '../components/AgentNodes';
import { theme } from '../components/theme';

const seedAgents = [
  { id: 'facebook-intake', name: 'Facebook Intake', role: 'Platform ingestion', lane: 'Conversation', platform: 'Facebook', status: 'IDLE', currentTask: '' },
  { id: 'linkedin-intake', name: 'LinkedIn Intake', role: 'Profile and post ingestion', lane: 'Conversation', platform: 'LinkedIn', status: 'IDLE', currentTask: '' },
  { id: 'x-intake', name: 'X Intake', role: 'Timeline and thread ingestion', lane: 'Conversation', platform: 'X', status: 'IDLE', currentTask: '' },
  { id: 'downloader', name: 'Downloader', role: 'File and export retrieval', lane: 'Reasoning', platform: 'General', status: 'IDLE', currentTask: '' },
  { id: 'memory-writer', name: 'Memory Writer', role: 'Session and knowledge persistence', lane: 'Memory', platform: 'General', status: 'IDLE', currentTask: '' },
  { id: 'draft-composer', name: 'Draft Composer', role: 'Drafting and transformation', lane: 'Reasoning', platform: 'General', status: 'IDLE', currentTask: '' },
  { id: 'diagnostics', name: 'Diagnostics', role: 'Runtime and state inspection', lane: 'Memory', platform: 'System', status: 'IDLE', currentTask: '' },
  { id: 'task-router', name: 'Task Router', role: 'General routing and assignment', lane: 'Conversation', platform: 'System', status: 'IDLE', currentTask: '' }
];

const quickCommands = [
  'Show diagnostics',
  'Connect LinkedIn',
  'Queue Facebook intake',
  'Download my X data',
  'Save this to memory',
  'Create a draft from uploaded files'
];

export default function InterfacePage() {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: 'ChatFace420 is standing. Give me a task, upload a file, drop content here, or run diagnostics.' }
  ]);
  const [input, setInput] = useState('');
  const [agents, setAgents] = useState(seedAgents);
  const [tasks, setTasks] = useState([]);
  const [uploads, setUploads] = useState([]);
  const [dragActive, setDragActive] = useState(false);
  const [micState, setMicState] = useState('Ready');

  const diagnostics = useMemo(() => ({
    agentCount: 160,
    visibleNodes: agents.length,
    queued: tasks.filter((t) => t.status === 'QUEUED').length,
    running: tasks.filter((t) => t.status === 'RUNNING').length,
    done: tasks.filter((t) => t.status === 'DONE').length,
    uploads: uploads.length,
    microphone: micState,
    supabase: 'Pending keys',
    connections: 'LinkedIn / X / Facebook ready for credentials'
  }), [agents.length, tasks, uploads.length, micState]);

  function runCommand(command) {
    const text = (command || input).trim();
    if (!text) return;
    const routed = routeCommand(text, agents, diagnostics);
    setMessages((prev) => [...prev, { role: 'user', content: text }, { role: 'assistant', content: routed.reply }]);
    setAgents(routed.agents);
    setTasks((prev) => [...routed.newTasks, ...prev].slice(0, 12));
    setInput('');
  }

  function updateAgentStatus(agentList, agentId, status, task) {
    return agentList.map((agent) => agent.id === agentId ? { ...agent, status, currentTask: task || agent.currentTask } : agent);
  }

  function routeCommand(text, currentAgents, currentDiagnostics) {
    const lower = text.toLowerCase();
    const taskId = `task-${Date.now()}`;
    let assigned = 'task-router';
    let status = 'RUNNING';
    let reply = `Task queued under Task Router: ${text}`;
    let updatedAgents = currentAgents;
    let taskName = text;

    if (lower.includes('diagnostic') || lower.includes('status')) {
      assigned = 'diagnostics';
      reply = [
        'DIAGNOSTICS',
        `Agents standing: ${currentDiagnostics.agentCount}`,
        `Visible work nodes: ${currentDiagnostics.visibleNodes}`,
        `Queued tasks: ${currentDiagnostics.queued}`,
        `Running tasks: ${currentDiagnostics.running}`,
        `Completed tasks: ${currentDiagnostics.done}`,
        `Uploads in session: ${currentDiagnostics.uploads}`,
        `Microphone: ${currentDiagnostics.microphone}`,
        `Supabase: ${currentDiagnostics.supabase}`,
        `Connections: ${currentDiagnostics.connections}`
      ].join('\n');
      taskName = 'Print diagnostics';
    } else if (lower.includes('facebook')) {
      assigned = 'facebook-intake';
      reply = 'Facebook Intake is running. ChatFace is preparing the Facebook connection lane and intake path.';
      taskName = 'Facebook intake';
    } else if (lower.includes('linkedin')) {
      assigned = 'linkedin-intake';
      reply = 'LinkedIn Intake is running. Profile and post import path is queued.';
      taskName = 'LinkedIn intake';
    } else if (lower.includes(' x ') || lower.startsWith('x ') || lower.includes('twitter') || lower.includes('x data')) {
      assigned = 'x-intake';
      reply = 'X Intake is running. Timeline and export path is queued.';
      taskName = 'X intake';
    } else if (lower.includes('download') || lower.includes('export')) {
      assigned = 'downloader';
      reply = 'Downloader is running. File retrieval or platform export path has been assigned.';
      taskName = 'Download task';
    } else if (lower.includes('memory') || lower.includes('save this')) {
      assigned = 'memory-writer';
      reply = 'Memory Writer is running. This session item has been marked for persistence.';
      taskName = 'Memory write';
    } else if (lower.includes('draft') || lower.includes('compose') || lower.includes('write')) {
      assigned = 'draft-composer';
      reply = 'Draft Composer is running. Draft preparation has been queued from current context.';
      taskName = 'Draft compose';
    }

    updatedAgents = updateAgentStatus(updatedAgents, assigned, status, taskName);
    const freshTask = [{ id: taskId, name: taskName, agentId: assigned, status, createdAt: new Date().toLocaleTimeString() }];
    return { reply, agents: updatedAgents, newTasks: freshTask };
  }

  function handleFiles(fileList) {
    const incoming = Array.from(fileList || []).map((file) => ({
      id: `${file.name}-${file.size}-${Date.now()}`,
      name: file.name,
      size: `${Math.max(1, Math.round(file.size / 1024))} KB`,
      type: file.type || 'unknown'
    }));
    if (!incoming.length) return;
    setUploads((prev) => [...incoming, ...prev].slice(0, 10));
    setMessages((prev) => [
      ...prev,
      { role: 'assistant', content: `Upload intake accepted ${incoming.length} file(s). Downloader and Memory Writer are now available for routing.` }
    ]);
  }

  return (
    <Layout title="Interface" subtitle="Task agents, drag uploads anywhere, run diagnostics, and prepare platform connections from one speaking surface.">
      <section style={styles.shell}>
        <div style={styles.chatPanel}>
          <div style={styles.label}>COMMAND SURFACE</div>
          <div
            style={{ ...styles.dropZone, ...(dragActive ? styles.dropActive : {}) }}
            onDragOver={(e) => { e.preventDefault(); setDragActive(true); }}
            onDragLeave={() => setDragActive(false)}
            onDrop={(e) => { e.preventDefault(); setDragActive(false); handleFiles(e.dataTransfer.files); }}
          >
            Drag files, exports, notes, images, or audio here. ChatFace routes intake to the right lane.
          </div>

          <div style={styles.messageBox}>
            {messages.map((message, index) => (
              <div key={index} style={{ ...styles.message, background: message.role === 'user' ? '#163022' : '#101a13' }}>
                <div style={styles.messageRole}>{message.role}</div>
                <div style={styles.messageText}>{message.content}</div>
              </div>
            ))}
          </div>

          <div style={styles.quickWrap}>
            {quickCommands.map((item) => (
              <button key={item} style={styles.quickButton} onClick={() => runCommand(item)}>{item}</button>
            ))}
          </div>

          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Tell ChatFace what you want done..."
            style={styles.input}
          />

          <div style={styles.controls}>
            <button style={styles.primary} onClick={() => runCommand()}>Send Task</button>
            <label style={styles.secondaryLabel}>
              Upload Files
              <input type="file" multiple hidden onChange={(e) => handleFiles(e.target.files)} />
            </label>
            <button style={styles.secondary} onClick={() => setMicState(micState === 'Listening' ? 'Ready' : 'Listening')}>
              Microphone: {micState}
            </button>
            <button style={styles.secondary} onClick={() => runCommand('Show diagnostics')}>Diagnostics</button>
          </div>
        </div>

        <div style={styles.sidePanel}>
          <div style={styles.card}>
            <div style={styles.label}>ACTIVE AGENT NODES</div>
            <AgentNodes agents={agents} />
          </div>
          <div style={styles.card}>
            <div style={styles.label}>TASK QUEUE</div>
            <div style={styles.taskList}>
              {tasks.length ? tasks.map((task) => (
                <div key={task.id} style={styles.taskItem}>
                  <div style={styles.taskName}>{task.name}</div>
                  <div style={styles.taskMeta}>{task.agentId} · {task.status} · {task.createdAt}</div>
                </div>
              )) : <div style={styles.empty}>No tasks yet. Send a command to activate the queue.</div>}
            </div>
          </div>
          <div style={styles.card}>
            <div style={styles.label}>UPLOADS</div>
            <div style={styles.taskList}>
              {uploads.length ? uploads.map((file) => (
                <div key={file.id} style={styles.taskItem}>
                  <div style={styles.taskName}>{file.name}</div>
                  <div style={styles.taskMeta}>{file.type} · {file.size}</div>
                </div>
              )) : <div style={styles.empty}>No uploads yet. Drag files onto the interface or use Upload Files.</div>}
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}

const styles = {
  shell: { display: 'grid', gridTemplateColumns: '1.3fr 1fr', gap: '18px' },
  chatPanel: { background: theme.panel, border: `1px solid ${theme.border}`, borderRadius: '18px', padding: '18px', boxShadow: theme.glow },
  sidePanel: { display: 'grid', gap: '18px', alignContent: 'start' },
  card: { background: theme.panel, border: `1px solid ${theme.border}`, borderRadius: '18px', padding: '18px', boxShadow: theme.glow },
  label: { color: theme.neon, fontSize: '12px', textTransform: 'uppercase', letterSpacing: '1.2px', marginBottom: '10px', fontWeight: 700 },
  dropZone: { border: `1px dashed ${theme.border}`, borderRadius: '14px', padding: '16px', marginBottom: '16px', color: theme.muted, background: '#0f1712' },
  dropActive: { background: '#153321', color: theme.text, boxShadow: theme.glow },
  messageBox: { minHeight: '360px', maxHeight: '520px', overflowY: 'auto', background: '#08100c', border: `1px solid ${theme.border}`, borderRadius: '14px', padding: '12px', marginBottom: '14px' },
  message: { border: `1px solid ${theme.border}`, borderRadius: '12px', padding: '12px', marginBottom: '10px' },
  messageRole: { color: theme.neon, fontSize: '12px', textTransform: 'uppercase', marginBottom: '6px', fontWeight: 700 },
  messageText: { color: theme.text, whiteSpace: 'pre-wrap', lineHeight: 1.6 },
  quickWrap: { display: 'flex', gap: '8px', flexWrap: 'wrap', marginBottom: '12px' },
  quickButton: { background: theme.panel2, color: theme.text, border: `1px solid ${theme.border}`, borderRadius: '999px', padding: '8px 12px', cursor: 'pointer' },
  input: { width: '100%', minHeight: '110px', resize: 'vertical', borderRadius: '12px', border: `1px solid ${theme.border}`, background: '#0a1430', color: theme.text, padding: '14px', fontSize: '16px', boxSizing: 'border-box', outline: 'none', marginBottom: '12px' },
  controls: { display: 'flex', flexWrap: 'wrap', gap: '10px' },
  primary: { background: theme.neon, color: '#041008', border: 'none', borderRadius: '10px', padding: '12px 18px', fontWeight: 700, cursor: 'pointer' },
  secondary: { background: theme.panel2, color: theme.text, border: `1px solid ${theme.border}`, borderRadius: '10px', padding: '12px 16px', fontWeight: 700, cursor: 'pointer' },
  secondaryLabel: { background: theme.panel2, color: theme.text, border: `1px solid ${theme.border}`, borderRadius: '10px', padding: '12px 16px', fontWeight: 700, cursor: 'pointer', display: 'inline-flex', alignItems: 'center' },
  taskList: { display: 'grid', gap: '10px' },
  taskItem: { border: `1px solid ${theme.border}`, borderRadius: '12px', padding: '10px', background: '#0f1712' },
  taskName: { color: theme.text, fontWeight: 700 },
  taskMeta: { color: theme.muted, fontSize: '12px', marginTop: '6px' },
  empty: { color: theme.muted, fontSize: '14px', lineHeight: 1.5 }
};
