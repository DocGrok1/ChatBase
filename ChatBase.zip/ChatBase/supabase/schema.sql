create extension if not exists pgcrypto;

create table if not exists chatface_sessions (
  id uuid primary key default gen_random_uuid(),
  title text,
  lane text default 'conversation',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists chatface_messages (
  id uuid primary key default gen_random_uuid(),
  session_id uuid references chatface_sessions(id) on delete cascade,
  role text not null,
  content text not null,
  lane text default 'conversation',
  created_at timestamptz not null default now()
);

create table if not exists chatface_agents (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  family text,
  role text,
  readiness text default 'staged',
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists chatface_models (
  id uuid primary key default gen_random_uuid(),
  key text not null unique,
  label text not null,
  lane text not null,
  is_enabled boolean not null default true,
  provider text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists chatface_uploads (
  id uuid primary key default gen_random_uuid(),
  session_id uuid references chatface_sessions(id) on delete set null,
  file_name text not null,
  mime_type text,
  storage_path text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists chatface_runtime_state (
  id uuid primary key default gen_random_uuid(),
  key text not null unique,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists platform_connections (
  id uuid primary key default gen_random_uuid(),
  platform text not null,
  account_label text,
  external_account_id text,
  status text not null default 'not_connected',
  access_token text,
  refresh_token text,
  token_expires_at timestamptz,
  scopes text[],
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists platform_posts (
  id uuid primary key default gen_random_uuid(),
  platform text not null,
  connection_id uuid references platform_connections(id) on delete set null,
  direction text not null default 'imported',
  status text not null default 'draft',
  title text,
  body text,
  media jsonb not null default '[]'::jsonb,
  engagement jsonb not null default '{}'::jsonb,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

insert into chatface_models (key, label, lane, provider)
values
  ('conversation', 'Conversation Lane', 'conversation', 'configure-provider'),
  ('reasoning', 'Reasoning Lane', 'reasoning', 'configure-provider'),
  ('memory', 'Memory Lane', 'memory', 'configure-provider')
on conflict (key) do nothing;
