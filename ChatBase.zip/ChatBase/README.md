# ChatBase

This archive is a cleaned stand-up base built from the stronger ChatFace platform shell, with the smarter interface and upload/whisper-ready endpoints merged in.

## What is included

- Next.js 14 app shell
- Home, Interface, Agents, Systems, Connections, About pages
- Smart command surface on `/interface`
- Upload intake endpoint placeholder at `/api/upload`
- Whisper-ready endpoint placeholder at `/api/whisper`
- Chat endpoint placeholder at `/api/chat`
- OAuth starter routes for LinkedIn, X, Facebook
- Supabase starter schema at `supabase/schema.sql`
- Vercel config and `.env.example`

## What this pack is for

Use this as the branch-off recovery base for standing the app back up cleanly.
It is the cleaner base archive, not a finished production runtime.

## Run locally

```bash
npm install
npm run dev
```

## Deploy

1. Upload this folder into the repo root.
2. Set the framework to Next.js in Vercel.
3. Add environment variables from `.env.example`.
4. Run `supabase/schema.sql` in Supabase.
5. Replace placeholder API logic with live provider and model wiring.

## Notes

- `ChatBase` is already a used public name in software, so treat it as a working repo name unless you confirm your final public naming.
- This base preserves the broader platform shell while keeping the stronger smart interface.
